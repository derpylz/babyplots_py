import os
from functools import reduce
from uuid import uuid4
import json
import numpy as np
from skimage import io
from skimage.util import img_as_float
from IPython.display import HTML, Javascript, display
import jinja2

im = img_as_float(io.imread('../RGB.tif'))
# im shape: z, x, y, c
print(im.shape, 'imshape before transpose')

channel_thresholds = [0.3, 0.1, 1] # RGB
for i, thres in enumerate(channel_thresholds):
    mask = im[:, :, :, i] < thres
    im[:, :, :, i][mask] = 0

print(im.shape)


# im = np.transpose(im, (3, 0, 2, 1))
# im = np.transpose(im, (3, 0, 1, 2)) # No
# im = np.transpose(im, (3, 2, 0, 1)) # Yes but no
im = np.transpose(im, (0, 3, 2, 1)) # Yes but almost
# im shape becomes z, c, y, x
print(im.shape, 'imshape after transpose')
attributes = {
    "dim": im.shape
}
n_vals = reduce(lambda x, y: x*y, im.shape)

im = np.reshape(im, n_vals)

print(im.shape)
print(im[0:5])